public class Cyclewhile {

    public static void main(String[] args) {

        int ticket = 200000;
        while (ticket <= 210000) {
            System.out.println("Ticket number from 200k to 210k: " + ticket);
            ticket++;
        }
        ticket = 220000;
        while (ticket <= 235000) {
            System.out.println("Ticket number from 220k to 235k: " + ticket);
            ticket++;
        }

    }
}
