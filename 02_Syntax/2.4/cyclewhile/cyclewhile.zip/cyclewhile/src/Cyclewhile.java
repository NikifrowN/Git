public class Cyclewhile {

    public static void main(String[] args) {

        int ticket = 200000;
        while (ticket <= 235000 ) {
            if (ticket <= 210000) {
                System.out.println("Ticket number from 200k to 210k: " + ticket);
            }
            if (ticket >= 220000 && ticket <=235000) {
                System.out.println("Ticket number from 220k to 235k: " + ticket);
            }
            ticket++;
        }

    }
}
